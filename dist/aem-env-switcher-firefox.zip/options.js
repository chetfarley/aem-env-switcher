// ---------------------------------------------------------------------------
// Storage schema (chrome.storage.sync)
// ---------------------------------------------------------------------------
//
// KEY: "envs"
// Type: Record<string, EnvConfig>
//
//   EnvConfig {
//     author:  string  — base URL of the AEM author instance, no trailing slash
//                        e.g. "https://dev-author.example.com"
//     publish: string  — base URL of the publish/dispatcher, no trailing slash
//                        e.g. "https://dev.example.com"
//   }
//
//   Built-in environment keys (always present, cannot be removed):
//     "localhost", "dev", "qa", "stage", "prod"
//   Custom environment keys: any user-supplied string
//
// Example:
//   {
//     localhost: { author: "http://localhost:4502", publish: "http://localhost:4503" },
//     dev:       { author: "https://dev-author.example.com", publish: "https://dev.example.com" },
//     prod:      { author: "https://author.example.com",     publish: "https://www.example.com" }
//   }
//
// ---------------------------------------------------------------------------
//
// KEY: "i18nMappings"
// Type: I18nMapping[]
//
//   I18nMapping {
//     masterPath:  string       — full JCR path to the Language Master root,
//                                 no trailing slash
//                                 e.g. "/content/komatsu/language-masters/en-us"
//     liveCopies:  LiveCopy[]  — one or more live copies fed by this master
//   }
//
//   LiveCopy {
//     label:      string  — human-readable label shown in dropdowns
//                           e.g. "NA – English (US)"
//     path:       string  — full JCR path to the live copy root, no trailing slash
//                           e.g. "/content/komatsu/websites/na/en-us"
//     maskedPath: string  — (optional) explicit publish-rewrite prefix for this
//                           live copy, no trailing slash.
//                           When present, the published URL is built as:
//                             publishBase + maskedPath + "/" + pagePath
//                           When empty/omitted, the masked path is DERIVED by
//                           stripping `path` from the full JCR URL, i.e.:
//                             publishBase + pagePath  (after removing the liveCopy prefix)
//                           e.g. "/en-us"
//   }
//
// Example:
//   [
//     {
//       masterPath: "/content/komatsu/language-masters/en-us",
//       liveCopies: [
//         { label: "NA – English (US)", path: "/content/komatsu/websites/na/en-us",  maskedPath: "/en-us" },
//         { label: "NA – English (CA)", path: "/content/komatsu/websites/na/en-ca",  maskedPath: "/en-ca" }
//       ]
//     },
//     {
//       masterPath: "/content/komatsu/language-masters/fr-ca",
//       liveCopies: [
//         { label: "NA – French (CA)",  path: "/content/komatsu/websites/na/fr-ca",  maskedPath: "/fr-ca" }
//       ]
//     }
//   ]
//
// ---------------------------------------------------------------------------
//
// MIGRATION NOTE
// The old keys "globalConfig" (localePath / languageMasterPath) are superseded
// by "i18nMappings". On first load the migration helper below converts any
// legacy data so nothing is lost.
//
// ---------------------------------------------------------------------------

/** @type {Record<string, {author: string, publish: string}>} */
const defaultEnvs = {
  localhost: { author: "http://localhost:4502", publish: "http://localhost:4503" },
  dev:       { author: "", publish: "" },
  qa:        { author: "", publish: "" },
  stage:     { author: "", publish: "" },
  prod:      { author: "", publish: "" },
};

/** @type {import('./options').I18nMapping[]} */
const defaultI18nMappings = [];

// Keep a reference to old name for any legacy code still using defaultConfig
const defaultConfig = defaultEnvs;

const envOrder = ["localhost", "dev", "qa", "stage", "prod"]; // display order

// Helper function to create environment input block
function createEnvBlock(key, urls) {
  const div = document.createElement("div");
  div.className = "env-block";
  div.innerHTML = `
    <h3>${key.toUpperCase()}</h3>
    <label>Author URL</label>
    <input type="url" name="${key}-author" value="${urls.author}" placeholder="https://${key}-author.example.com">
    <label>Publish URL</label>
    <input type="url" name="${key}-publish" value="${urls.publish}" placeholder="https://${key}.example.com">
    ${!["localhost", "dev", "qa", "stage", "prod"].includes(key)
      ? `<button type="button" class="removeEnvBtn" data-env="${key}">Remove</button>`
      : ""}
  `;
  return div;
}

// Render global config inputs
function renderGlobalInputs(globalConfig) {
  const container = document.getElementById("globalInputs");
  container.innerHTML = `
    <div class="env-block">
      <h3>Global Path Settings</h3>
      <label>Locale Path <small>(e.g. content/komatsu/websites/na/en-us)</small></label>
      <input type="text" name="global-localePath" value="${globalConfig.localePath || ""}" placeholder="content/site/region/en-us">
      <label>Language Master Path <small>(e.g. content/komatsu/language-masters/en-us)</small></label>
      <input type="text" name="global-languageMasterPath" value="${globalConfig.languageMasterPath || ""}" placeholder="content/site/language-masters/en-us">
    </div>
  `;
}

// Render environment inputs dynamically
function renderInputs(envs) {
  const container = document.getElementById("envInputs");
  container.innerHTML = "";

  // First render ordered environments
  for (const key of envOrder) {
    const urls = envs[key];
    if (!urls) continue;
    container.appendChild(createEnvBlock(key, urls));
  }
  
  // Then render any custom environments (not in envOrder)
  for (const [key, urls] of Object.entries(envs)) {
    if (envOrder.includes(key)) continue; // Skip already rendered
    container.appendChild(createEnvBlock(key, urls));
  }

  // Attach remove listeners
  document.querySelectorAll(".removeEnvBtn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const env = e.target.dataset.env;
      delete envs[env];
      renderInputs(envs);
    });
  });
}

// ---------------------------------------------------------------------------
// Migration: convert legacy globalConfig → i18nMappings
// ---------------------------------------------------------------------------
async function migrateIfNeeded() {
  const data = await chrome.storage.sync.get(["globalConfig", "i18nMappings"]);

  // Already migrated (or nothing to migrate)
  if (data.i18nMappings !== undefined) return;
  if (!data.globalConfig) return;

  const { localePath = "", languageMasterPath = "" } = data.globalConfig;

  // Only attempt migration when both paths were configured
  if (!localePath || !languageMasterPath) return;

  // Derive locale from the trailing xx-xx segment of each path
  const localeRe = /\/([a-z]{2}-[a-z]{2})$/i;
  const lmMatch  = languageMasterPath.match(localeRe);
  const lcMatch  = localePath.match(localeRe);

  if (!lmMatch || !lcMatch) return;

  const masterPath = "/" + languageMasterPath.replace(/^\/|\/$/, "");
  const livePath   = "/" + localePath.replace(/^\/|\/$/, "");
  const locale     = lcMatch[1];

  /** @type {import('./options').I18nMapping[]} */
  const i18nMappings = [
    {
      masterPath,
      liveCopies: [
        { label: locale.toUpperCase(), path: livePath, maskedPath: "/" + locale }
      ]
    }
  ];

  await chrome.storage.sync.set({ i18nMappings });
  console.info("[AEM Env Switcher] Migrated legacy globalConfig to i18nMappings", i18nMappings);
}

// ---------------------------------------------------------------------------
// Load stored settings
// ---------------------------------------------------------------------------
async function loadSettings() {
  await migrateIfNeeded();
  const { envs, i18nMappings } = await chrome.storage.sync.get(["envs", "i18nMappings"]);
  renderGlobalInputs(i18nMappings || defaultI18nMappings);
  renderInputs(envs || defaultEnvs);
}

// ---------------------------------------------------------------------------
// Save settings
// ---------------------------------------------------------------------------
// Collects envs from the form.  i18nMappings are saved separately by
// saveI18nMappings() which is called from the Masters & Live Copies UI.
document.getElementById("envForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const inputs = e.target.querySelectorAll("input");
  const envs = {};

  for (const input of inputs) {
    // Skip i18n mapping inputs — handled by their own save path
    if (input.name.startsWith("i18n-")) continue;

    const dashIdx = input.name.indexOf("-");
    if (dashIdx === -1) continue;
    const env  = input.name.slice(0, dashIdx);
    const type = input.name.slice(dashIdx + 1);
    envs[env] = envs[env] || {};
    envs[env][type] = input.value.replace(/\/$/, "");
  }

  await chrome.storage.sync.set({ envs });
  alert("Environments saved!");
});

// ---------------------------------------------------------------------------
// i18n Mappings — save helper (called by the Masters & Live Copies UI)
// ---------------------------------------------------------------------------

/**
 * Reads i18nMappings from the DOM (built by renderGlobalInputs) and persists
 * them to chrome.storage.sync.
 *
 * Each LM block renders hidden/text inputs following this naming convention:
 *   i18n-lm-{lmIndex}-masterPath          — the LM JCR path
 *   i18n-lc-{lmIndex}-{lcIndex}-label     — live copy label
 *   i18n-lc-{lmIndex}-{lcIndex}-path      — live copy JCR path
 *   i18n-lc-{lmIndex}-{lcIndex}-maskedPath — live copy masked publish path
 *
 * @returns {Promise<void>}
 */
async function saveI18nMappings() {
  const form = document.getElementById("envForm");
  const inputs = form.querySelectorAll("input[name^='i18n-']");

  // Group by lmIndex first
  const lmMap = new Map(); // lmIndex → { masterPath, liveCopies: Map<lcIndex, LiveCopy> }

  for (const input of inputs) {
    // i18n-lm-{lmIndex}-masterPath
    const lmMatch = input.name.match(/^i18n-lm-(\d+)-(.+)$/);
    if (lmMatch) {
      const lmIndex = Number(lmMatch[1]);
      const field   = lmMatch[2];
      const entry   = lmMap.get(lmIndex) || { masterPath: "", liveCopies: new Map() };
      if (field === "masterPath") entry.masterPath = normalizePath(input.value);
      lmMap.set(lmIndex, entry);
      continue;
    }

    // i18n-lc-{lmIndex}-{lcIndex}-{field}
    const lcMatch = input.name.match(/^i18n-lc-(\d+)-(\d+)-(.+)$/);
    if (lcMatch) {
      const lmIndex = Number(lcMatch[1]);
      const lcIndex = Number(lcMatch[2]);
      const field   = lcMatch[3];
      const entry   = lmMap.get(lmIndex) || { masterPath: "", liveCopies: new Map() };
      const lc      = entry.liveCopies.get(lcIndex) || { label: "", path: "", maskedPath: "" };
      if (field === "label")      lc.label      = input.value.trim();
      if (field === "path")       lc.path       = normalizePath(input.value);
      if (field === "maskedPath") lc.maskedPath = normalizePath(input.value);
      entry.liveCopies.set(lcIndex, lc);
      lmMap.set(lmIndex, entry);
    }
  }

  // Convert Maps → sorted arrays, drop empty masters
  const i18nMappings = Array.from(lmMap.entries())
    .sort(([a], [b]) => a - b)
    .map(([, entry]) => ({
      masterPath: entry.masterPath,
      liveCopies: Array.from(entry.liveCopies.entries())
        .sort(([a], [b]) => a - b)
        .map(([, lc]) => lc)
        .filter(lc => lc.path), // require at minimum a JCR path
    }))
    .filter(m => m.masterPath);

  await chrome.storage.sync.set({ i18nMappings });
  return i18nMappings;
}

/** Strips leading/trailing whitespace and ensures a single leading slash. */
function normalizePath(value) {
  const trimmed = value.trim().replace(/\/$/, "");
  if (!trimmed) return "";
  return trimmed.startsWith("/") ? trimmed : "/" + trimmed;
}

// Export configuration to JSON file
document.getElementById("exportBtn").addEventListener("click", async () => {
  const { envs, i18nMappings } = await chrome.storage.sync.get(["envs", "i18nMappings"]);
  const config = {
    envs:         envs         || defaultEnvs,
    i18nMappings: i18nMappings || defaultI18nMappings,
  };
  
  const dataStr = JSON.stringify(config, null, 2);
  const blob = new Blob([dataStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement("a");
  a.href = url;
  a.download = `aem-env-config-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  alert("Configuration exported!");
});

// Import configuration from JSON file
document.getElementById("importBtn").addEventListener("click", () => {
  document.getElementById("importFile").click();
});

document.getElementById("importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  
  try {
    const text = await file.text();
    const config = JSON.parse(text);
    
    // Validate that the imported config has the expected structure
    if (typeof config !== "object" || config === null) {
      throw new Error("Invalid configuration format");
    }

    // Support formats:
    //   v2 (new):    { envs, i18nMappings }
    //   v1 (legacy): { envs, globalConfig }
    //   v0 (flat):   { localhost: {...}, dev: {...}, ... }
    const envsToImport      = config.envs || config;
    const i18nToImport      = config.i18nMappings || null;
    const legacyGlobalConfig = config.globalConfig || null;

    // Validate each environment has author and publish properties
    for (const [env, urls] of Object.entries(envsToImport)) {
      if (env === "globalConfig" || env === "i18nMappings") continue;
      if (typeof urls !== "object" || !("author" in urls) || !("publish" in urls)) {
        throw new Error(`Environment "${env}" is missing required properties`);
      }
    }

    // Resolve i18n data — prefer new format, fall back to migrating legacy
    let resolvedI18n = defaultI18nMappings;
    if (i18nToImport) {
      resolvedI18n = i18nToImport;
    } else if (legacyGlobalConfig) {
      // Temporarily store the legacy key so migrateIfNeeded() can convert it
      await chrome.storage.sync.set({ globalConfig: legacyGlobalConfig, i18nMappings: undefined });
      await migrateIfNeeded();
      const { i18nMappings: migrated } = await chrome.storage.sync.get("i18nMappings");
      resolvedI18n = migrated || defaultI18nMappings;
    }

    // Save to storage and re-render
    await chrome.storage.sync.set({ envs: envsToImport, i18nMappings: resolvedI18n });
    renderGlobalInputs(resolvedI18n);
    renderInputs(envsToImport);
    alert("Configuration imported successfully!");
  } catch (error) {
    alert(`Failed to import configuration: ${error.message}`);
  }
  
  // Reset file input
  e.target.value = "";
});

// Add custom environment
document.getElementById("addEnvBtn").addEventListener("click", async () => {
  const { envs } = await chrome.storage.sync.get("envs");
  const config = envs || defaultEnvs;
  const newEnv = prompt("Enter a new environment name (e.g. 'sandbox' or 'demo'):");
  if (newEnv && newEnv.trim() && !config[newEnv.trim()]) {
    config[newEnv.trim()] = { author: "", publish: "" };
    renderInputs(config);
  }
});

loadSettings();
