var l=["localhost","dev","qa","stage","prod"],_={localhost:{author:"http://localhost:4502",publish:"http://localhost:4503"},dev:{author:"",publish:""},qa:{author:"",publish:""},stage:{author:"",publish:""},prod:{author:"",publish:""}};async function E(e){await customElements.whenDefined("md-dialog");let t=document.getElementById("envs-dialog"),n=document.getElementById("open-envs-config"),a=document.getElementById("config-menu");p(t),n.addEventListener("click",async()=>{a.open=!1,await h(t),t.show()}),t.querySelector(".envs-dialog__save").addEventListener("click",async()=>{await g(t)&&(t.close(),e?.())}),t.querySelector(".envs-dialog__cancel").addEventListener("click",()=>{t.close()}),t.querySelector(".envs-dialog__add").addEventListener("click",()=>{f(t)})}function p(e){if(e.dataset.initialized)return;e.dataset.initialized="true",e.setAttribute("aria-label","Environments configuration");let t=document.createElement("div");t.setAttribute("slot","headline"),t.className="envs-dialog__headline",t.innerHTML=`
    <md-icon aria-hidden="true">dns</md-icon>
    <span>Environments</span>
  `,e.appendChild(t);let n=document.createElement("div");n.setAttribute("slot","content"),n.className="envs-dialog__content",n.innerHTML=`
    <p class="envs-dialog__hint">
      Configure the Author and Publish base URLs for each environment.
      Built-in environments cannot be renamed or removed.
    </p>
    <div class="envs-dialog__list" role="list" aria-label="Environment list">
      <!-- Populated dynamically by _renderEnvList() -->
    </div>
    <div class="envs-dialog__add-row">
      <md-outlined-button class="envs-dialog__add" type="button">
        <md-icon slot="icon" aria-hidden="true">add</md-icon>
        Add Environment
      </md-outlined-button>
    </div>
    <div class="envs-dialog__error" role="alert" aria-live="assertive"></div>
  `,e.appendChild(n);let a=document.createElement("div");a.setAttribute("slot","actions"),a.className="envs-dialog__actions",a.innerHTML=`
    <md-text-button class="envs-dialog__cancel" type="button">Cancel</md-text-button>
    <md-filled-button class="envs-dialog__save" type="button">Save</md-filled-button>
  `,e.appendChild(a)}async function h(e){let{envs:t}=await chrome.storage.sync.get("envs"),n=t||_;m(e),b(e,n)}function b(e,t){let n=e.querySelector(".envs-dialog__list");n.innerHTML="";let a=l.filter(s=>t[s]!==void 0),o=Object.keys(t).filter(s=>!l.includes(s)).sort((s,r)=>s.localeCompare(r));for(let s of[...a,...o])n.appendChild(u(s,t[s],l.includes(s)))}function u(e,t,n){let a=document.createElement("div");return a.className=`envs-card${n?" envs-card--builtin":""}`,a.setAttribute("role","listitem"),a.dataset.envKey=e,a.innerHTML=`
    <div class="envs-card__header">
      ${n?`<span class="envs-card__name" aria-label="Environment name">${d(e)}</span>`:`<md-outlined-text-field
             class="envs-card__name-input"
             label="Name"
             value="${i(e)}"
             maxlength="32"
             pattern="[a-zA-Z0-9_-]+"
             supporting-text="Letters, numbers, - _ only"
             aria-label="Environment name"
           ></md-outlined-text-field>`}
      ${n?"":`<md-icon-button class="envs-card__remove" type="button" title="Remove ${i(e)}">
             <md-icon aria-hidden="true">delete</md-icon>
           </md-icon-button>`}
    </div>
    <div class="envs-card__fields">
      <md-outlined-text-field
        class="envs-card__author"
        type="url"
        label="Author URL"
        value="${i(t.author||"")}"
        placeholder="https://author.example.com"
        supporting-text="No trailing slash"
        aria-label="${d(e)} author URL"
      ></md-outlined-text-field>
      <md-outlined-text-field
        class="envs-card__publish"
        type="url"
        label="Publish URL"
        value="${i(t.publish||"")}"
        placeholder="https://www.example.com"
        supporting-text="No trailing slash"
        aria-label="${d(e)} publish URL"
      ></md-outlined-text-field>
    </div>
  `,a.querySelector(".envs-card__remove")?.addEventListener("click",()=>{a.remove()}),a}function f(e){let t=e.querySelector(".envs-dialog__list"),n=u("",{author:"",publish:""},!1);n.dataset.isNew="true",t.appendChild(n),n.scrollIntoView({behavior:"smooth",block:"nearest"});let a=n.querySelector(".envs-card__name-input");requestAnimationFrame(()=>a?.focus())}async function g(e){m(e);let t=e.querySelectorAll(".envs-card"),n={},a=new Set;for(let o of t){let s;if(o.classList.contains("envs-card--builtin")?s=o.dataset.envKey:s=(o.querySelector(".envs-card__name-input")?.value||"").trim().toLowerCase(),!s)return c(e,"One or more environments is missing a name."),o.querySelector(".envs-card__name-input")?.focus(),!1;if(!/^[a-zA-Z0-9_-]+$/.test(s))return c(e,`"${s}" is not a valid environment name. Use letters, numbers, - or _.`),!1;if(a.has(s))return c(e,`Duplicate environment name: "${s}".`),!1;a.add(s);let r=(o.querySelector(".envs-card__author")?.value||"").trim().replace(/\/$/,""),v=(o.querySelector(".envs-card__publish")?.value||"").trim().replace(/\/$/,"");n[s]={author:r,publish:v}}return await chrome.storage.sync.set({envs:n}),!0}function c(e,t){let n=e.querySelector(".envs-dialog__error");n&&(n.textContent=t)}function m(e){let t=e.querySelector(".envs-dialog__error");t&&(t.textContent="")}function d(e){return e.charAt(0).toUpperCase()+e.slice(1)}function i(e){return String(e).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}export{l as BUILTIN_ENVS,E as initEnvsDialog};
